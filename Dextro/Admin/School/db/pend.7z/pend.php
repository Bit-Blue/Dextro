<?php
include('../../db.php');
$yearly=0;
$monthly=0;

//Modified By Ranjeet || 23-Sep
$drpMedium=$_POST['drpMedium'];
$drpStd=$_POST['drpStd'];
$drpSec=$_POST['drpSec'];
$selectedMonths = $_POST['selectedMonths'];//Added | Ranjeet | 24-Nov
// $newSelectedMonth  = $_POST['newSelectedMonth'];//For month


				// and sch_tran.Month in  (".$selectedMonths.") //'Per Year'
$exeQuery=mysqli_query($con,"Select user.Gr_num, user.fee_type, user.Name, user.fee 
				,user.Medium,user.Std,user.Section FROM 
				( 
				select user_sch.Gr_num, sch_cls_fee.fee_type, user_sch.Name, sch_cls_fee.fee 
				,user_sch.Medium,user_sch.Std,user_sch.Section
				from user_sch 
				Inner Join sch_cls_fee
				On user_sch.Medium=sch_cls_fee.Medium 
				And user_sch.Std=sch_cls_fee.Std AND sch_cls_fee.one_time ='Per Year'  
				AND user_sch.Medium = '".$drpMedium."' AND user_sch.Std = '".$drpStd."' 
				AND user_sch.Section = '".$drpSec."' 
				) as user 
				LEFT JOIN sch_tran ON user.Gr_num = sch_tran.Gr_num  and sch_tran.fee_type = user.fee_type 
				where  sch_tran.Gr_num is NULL 
				order by user.Gr_num");


// $exeQuery = mysql_query($queryContents);
$count_Rows = 0 ; 
$yearlyData = array();
if($exeQuery === FALSE ){//|| mysql_num_rows($exeQuery)== 0){
	 die(mysql_error()); 
  echo('No fee has been added, try adding fees.');
	exit;
}
else{

   // while($fetchSet = mysql_fetch_array($exeQuery)) {

?>
	<div class="main-container">
		<div class="post-header">
			<span class="yearly">Pending Fees ( Yearly Fee )</span>
		</div>
		<div class="post-content">
			<div class="post-text">
				<ul class="table-view">
					<li class="table-view-header"  style="width:200px;">
						Name
					</li>
					<li class="table-view-header" style="width:100px;">
						Med
					</li>
					<li class="table-view-header" style="width:100px;">
						Std
					</li>
					<li class="table-view-header" style="width:100px;">
						Sec
					</li>
					<li class="table-view-header" style="width:100px;">
						GR Number
					</li>
					<li class="table-view-header" style="width:100px;">
						Amount
					</li>
					<li class="table-view-header" style="width:auto">
						Fee type
					</li>
				</ul>
			
		<?php
		// foreach($arr1 as $key=>$val){
		while($fetchSet = mysqli_fetch_row($exeQuery)) {
			//$yearlyData = $fetchSet[$count_Rows];
		?>
			<ul class="table-view">
					<li style="width:200px;">
						<?php echo $fetchSet[2];?>
					</li>
					<li style="width:100px;">
						<?php echo $fetchSet[4];?>
					</li>
					<li style="width:100px;">
						<?php echo $fetchSet[5];?>
					</li>
					<li style="width:100px;">
						<?php echo $fetchSet[6];?>
					</li>
					<li style="width:100px;">
						<?php echo $fetchSet[0];?>
					</li>
					<li style="width:100px;">
						<?php echo $fetchSet[3];
						$yearly=$yearly+$fetchSet[3];
						?>
					</li>
					<li  class="revenue-pend" style="width:auto;">
						<?php echo $fetchSet[1];?>
					</li>
				</ul>
				<?php
				$count_Rows += 1 ; //increase count for while loop
		  }
}
?>
<ul class="table-view">
					<li class="table-view-header" style="width:100px;">
						
					</li>
					<li class="table-view-header" style="width:100px;">
						Total Pending Fee
					</li>
					<li class="table-view-header" style="width:110px;">
						<?php echo $yearly;?>
					</li>
					<li class="table-view-header" style="width:100px;">
						
					</li>
				</ul>
	</div>
</div>
<div class="post-header">
			<span>Pending Fees ( Monthly Fee )</span>
		</div>
		<div class="post-content">
			<div class="post-text">
			<?php
				$totalUserquery=mysqli_query($con,"Select user_sch.Gr_num, sch_cls_fee.fee_type, user_sch.Name, sch_cls_fee.fee
					,user_sch.Medium,user_sch.Std,user_sch.Section
				from user_sch
				Inner Join sch_cls_fee
				On user_sch.Medium=sch_cls_fee.Medium 
				And user_sch.Std=sch_cls_fee.Std 
				AND user_sch.Medium = '".$drpMedium."' AND user_sch.Std = '".$drpStd."' 
				AND user_sch.Section = '".$drpSec."' 
				where sch_cls_fee.one_time ='Per Month' and sch_cls_fee.one_time not in ('Per Year')
				order by user_sch.Gr_num	
		");
				// echo "Select user_sch.Gr_num, sch_cls_fee.fee_type, user_sch.Name, sch_cls_fee.fee
				// 	,user_sch.Medium,user_sch.Std,user_sch.Section
				// from user_sch
				// Inner Join sch_cls_fee
				// On user_sch.Medium=sch_cls_fee.Medium 
				// And user_sch.Std=sch_cls_fee.Std 
				// AND user_sch.Medium = '".$drpMedium."' AND user_sch.Std = '".$drpStd."' 
				// AND user_sch.Section = '".$drpSec."' 
				// where sch_cls_fee.one_time ='Per Month'
				// order by user_sch.Gr_num";
// $totalTransQuery=mysqli_query($con,"Select user_sch.Gr_num, sch_tran.fee_type ,user_sch.Name, sch_tran.amount, sch_tran.month
// 				,user_sch.Medium,user_sch.Std,user_sch.Section
// 				from user_sch
// 				Inner Join sch_tran
// 				On user_sch.Gr_num=sch_tran.Gr_num  
// 				AND user_sch.Medium = '".$drpMedium."' AND user_sch.Std = '".$drpStd."' 
// 				AND user_sch.Section = '".$drpSec."' 
// 				where sch_tran.month NOT In ('One time') AND sch_tran.Month in  (".$selectedMonths.") 
// 				order by user_sch.Gr_num
// 		");
if($totalUserquery === FALSE ){//|| mysql_num_rows($exeQuery)== 0){
	 die(mysql_error()); 
  echo('No fee has been added, try adding fees.');
	exit;
}
else{

			?>
				<ul class="table-view">
					<li class="table-view-header" style="width:200px;">
						Name
					</li>
					<li class="table-view-header" style="width:100px;">
						Med
					</li>
					<li class="table-view-header" style="width:100px;">
						Std
					</li>
					<li class="table-view-header" style="width:100px;">
						Sec
					</li>
					<li class="table-view-header" style="width:100px;">
						GR Number
					</li>
					<li class="table-view-header" style="width:100px;">
						Amount
					</li>
					<li class="table-view-header" style="width:110px;">
						Month
					</li>
				</ul>
				
				<?php 
				
				while($val = mysqli_fetch_row($totalUserquery)) {
				// $mon=array('Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar','Apr','May');
				
				// $mon=array_slice($mon,0,$month);
					//newSelectedMonth
				 $mon  = explode(',', $selectedMonths);
			//	$mon  = explode(',', $newSelectedMonth);
				$mon_query=mysqli_query($con,"select  Month, Amount from sch_tran  where Gr_num='".$val[0]."' And fee_type='".$val[1]."' " ) ;
				// echo "select  Month,Amount from sch_tran  where Gr_num='".$val[0]."' And fee_type='".$val[1]."' ";
				 $j =0 ;
				
				while($mon_add=mysqli_fetch_array($mon_query)){
					$add[$j]= "'".$mon_add[0]."'";
					 $j++;
				}
				$k = 0 ;
				$months = "";
				$t_amount = 0 ;
				if(empty($add)){
							foreach($mon as $key){
								$months = $months ." " .$key;
								$t_amount = $t_amount +  $val[3];
							// echo $key;
						}}
						else{
							// print_r($add);
							
						foreach(array_diff($mon,$add) as $key){
							// echo $key." ";
							$months = $months." " .$key;
							$t_amount = $t_amount +  $val[3];
						}}
						if($months != ""){

		?>
			<ul class="table-view">
					<li style="width:200px;">
						<?php echo $val[2];?>
					</li>
					<li style="width:100px;">
						<?php echo $val[4];?>
					</li>
					<li style="width:100px;">
						<?php echo $val[5];?>
					</li>
					<li style="width:100px;">
						<?php echo $val[6];?>
					</li>
					<li style="width:100px;">
						<?php echo $val[0];?>
					</li>
					<li style="width:100px;">
						<?php 
						// $t_amount = $t_amount +  $val[3];
						echo $t_amount ;
						$monthly=$t_amount+$monthly;
						;?>
					</li>
					<li  class="revenue-pend" style="width:auto;">
						<?php
						//echo "Test";//$add; 
						echo $months;
						// print_r($mon);
						?>
					</li>
				</ul>
				<?php
			}
		}
	}
		
?>
<ul class="table-view">
					<li class="table-view-header" style="width:100px;">
						
					</li>
					
					<li class="table-view-header" style="width:100px;">
						Total Pending Fee
					</li>
					<li class="table-view-header" style="width:110px;">
						<?php echo $monthly;?>
					</li>
					<li class="table-view-header" style="width:100px;">
						
					</li>
				</ul>
</div>
</div>
</div>
<?php
exit;
?>
